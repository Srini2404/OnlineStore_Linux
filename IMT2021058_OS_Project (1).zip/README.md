# OnlineStore_Linux
The objective of this project is to develop an online retail store management system using Linux systems programming.  The system shall be able to manage the entire inventory of the store and process orders from customers in a timely and efficient manner.


# This shall contain the codes for having to communicate between the server and the client.
1 (Client->Server) - This shall be for Display all the products.
2 (Client->Server) - This shall be for Display of his cart.
3 (Client -> Server) - This shall be for placing an order
4 (Client->Server) - This shall for editing the cart.
5 (Client-> Server) - This is for the payment .
1 (Direct Terminal in Admin prog) - Add a product

2 (Direct Terminal in Admin prog) - Del a product

3 (Direct Terminal in Admin prog) - Update the quantity of the product.

4 (Direct Terminal in Admin prog) - Update the price of the particular product

# Important tips to keep in mind

1) Never assign any ID value as zero - because this is the default value that the struct's id will be initialized to.



* status 1 in the order struct means that the order has been purchased.

# Testing requirements :-

1) F